package GUI;

import javax.swing.JPanel;

/**
 * SetInitial
 */
public class SetInitial extends JPanel{

    public SetInitial(){
        
    }
}